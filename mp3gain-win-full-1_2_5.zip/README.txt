If MP3Gain will not start and you get a message about a missing file
(probably MSCOMCTL.OCX or MSVBVM60.DLL), please go back to the MP3Gain
home page

http://mp3gain.sourceforge.net

and download the "full" installer. Run this program, and
the needed Microsoft system files will be installed on your computer.

If you later download a new version of MP3Gain, you will NOT need to
download the "full" version again. The "normal" version will be all
you need.

